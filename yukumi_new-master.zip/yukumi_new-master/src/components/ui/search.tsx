"use client"

export const Search = ({ className }: { className?: string }) => {
  return <Search className={className} />
}

