import ContentUpload from "@/components/content-upload"

export default function Home() {
  return (
    <main>
      <ContentUpload />
    </main>
  )
}

