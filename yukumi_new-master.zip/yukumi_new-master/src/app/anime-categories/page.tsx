"use client"

import CategorySelector from "@/components/category-selector"

export default function SyntheticV0PageForDeployment() {
  return <CategorySelector />
}